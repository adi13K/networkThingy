import express, { Request, Response } from 'express';
import cors from 'cors';
import bodyParser from 'body-parser';
import connectDB from './database';
import User from './models/User';

const app = express();
const PORT = 5000;

// Middleware
app.use(cors());
app.use(bodyParser.json());

// Root route
app.get('/', (req: Request, res: Response) => {
  res.send('Welcome to the Express server!');
});

app.post('/api/users', async (req: Request, res: Response) => {
  const { name, email, password } = req.body;

  try {
    const newUser = new User({ name, email, password });
    await newUser.save();
    res.status(201).json({ message: 'User created successfully!', user: newUser });
  } catch (error) {
    res.status(500).json({ message: 'Error creating user', error });
  }
});

app.get('/api/users', async (req: Request, res: Response) => {
    try {
      const users = await User.find();
      res.status(200).json(users);
    } catch (error) {
      res.status(500).json({ message: 'Error fetching users', error });
    }
  });

// Test route
app.get('/api/test', (req: Request, res: Response) => {
  console.log('GET /api/test was called'); // Debug log
  res.json({ message: 'Hello from TypeScript Express!' });
});

// Start the server
app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});
